# DataPreparationExample1.R
# Copyright 2016 by Ernst Henle
# Work done by Ernst Henle, Roy Satyajit, and Nitin Dadlani

# Clear Workspace
rm(list=ls())
# Clear Console:
cat("\014")

# DataPrep Item 1 / Solution 1
url <- "https://archive.ics.uci.edu/ml/machine-learning-databases/wine/wine.data"
WINE <- read.csv(url, header=FALSE, stringsAsFactors=FALSE)

# DataPrep Item 2
# Manually construct a vector of column using
# https://archive.ics.uci.edu/ml/machine-learning-databases/wine/wine.data#
# Attribute Information:
# 1. Index
# 2. Alcohol quantity of Alcohol
# 3. MalicAcid  quantity of Malic Acid
# 4. Ash  quantity of Ash
# 5. AlcalinityAsh  Alcalinity of Ash
# 6. Magnesium  quantity of Magnesium
# 7. Phenols  Total phenols quantity
# 8. Flavanoids  quantity of flavanoids
# 9. NonFlavanoidPhenols   quantity of non flavanoids phelons
# 10. Proanthocyanins  quantity of proanthocyanins
# 11. ColorIntensity Intensity of colors
# 12. Hue  quantity of hue
# 13. OD280OD315   OD280/OD315 of diluted wines
# 14. Proline  quantity of proline 

# Solution 2
headers <- c("Index", "Alcohol","MalicAcid","Ash","AlcalinityAsh","Magnesium", "Phenols","Flavanoids","NonFlavanoidPhenols",
                          "Proanthocyanins", "ColorIntensity", "Hue", "OD280OD315", "Proline") 

# Associate names with the dataframe
names(WINE) <- headers

# DataPrep Item 3 / Solution 3
head(WINE)

# DataPrep Item 4
# na.rm = TRUE removes NAs from the calculation in medain(x, na.rm = TRUE); mean(x, na.rm = TRUE); sd(x, na.rm = TRUE); 

# Solution 4
?sapply
sapply(WINE, mean, na.rm=TRUE)
sapply(WINE, sd, na.rm=T)
sapply(WINE, median, na.rm=T)

# Another way to determine mean and median
summary(WINE)

# DataPrep Item 5
# Plot all histograms.  Note that Gender doesn't plot because it isn't numeric
# Solution 5
hist(WINE$Index, col="cyan")
hist(WINE$Alcohol, col="cyan")
hist(WINE$MalicAcid, col="cyan")
hist(WINE$Ash, col="cyan")
hist(WINE$AlcalinityAsh, col="cyan")
hist(WINE$Magnesium, col="cyan")
hist(WINE$Phenols, col="cyan")
hist(WINE$Flavanoids, col="cyan")
hist(WINE$NonFlavanoidPhenols, col="cyan")
hist(WINE$Proanthocyanins, col="cyan")
hist(WINE$ColorIntensity, col="cyan")
hist(WINE$Hue, col="cyan")
hist(WINE$OD280OD315, col="cyan")
hist(WINE$Proline, col="cyan")

# DataPrep Item 6 /Solution 6
head(WINE)
plot(WINE, col="blue")
#
# DataPrep Item 7
# This matrix of plots allows a data scientist to get a quick overview of distributions between attributes.
# Solution 7 (Example)
# When points are only found at smaller values values, for example three on one of the dimensions, then that dimension is trinary.
# Index is trinar
# When the scatter plots form recognizable curves or lines, then two attributes are correlated.  
# Ash and AlcalinityAsh are correlated

####################################
# Clean up workspace
rm(list=ls())
# Clear Console:
cat("\014")



# assign a url to variable "url"
url <- "https://archive.ics.uci.edu/ml/machine-learning-databases/autos/imports-85.data"
# Download a rectangular dataset
AUTO <- read.csv(url, header=FALSE, stringsAsFactors=FALSE)

# How many rows and columns are in the dataframe?
nrow(AUTO)
ncol(AUTO)

# view the column names
names(AUTO)

# DataPrep Item 8 a)
# Remove Outliers: use Compression ratio attribute, this is the 21at column - V21

v <- c(AUTO[ , 21])
highLimit <- mean(v) + 2*sd(v)
lowLimit <- mean(v) - 2*sd(v)
goodFlag <- (v < highLimit) & (v > lowLimit)
v <- v[goodFlag]
v
v <- v[goodFlag]
v

# DataPrep Item 8 b)
# Replace Outlier
v <- c(AUTO[ , 21])
highLimit <- mean(v) + 2*sd(v)
lowLimit <- mean(v) - 2*sd(v)
badFlag <- (v > highLimit) | (v <  lowLimit) # !goodFlag
v[badFlag] <- mean(v)
v

# DataPrep Item 8 c)
# Remove missing data: use horsepower attribute, this is the 22nd column - V22
v1 <- c(AUTO[ , 22])
v1[v1 == '?']<-NA
v1<-v1[!is.na(v1)]
v1

# DataPrep Item 8 d)
# Replace missing data with 0
v1 <- c(AUTO[ , 22])
v1[v1 == '?']<-NA
v1[is.na(v1)]<-0
v1

# DataPrep Item 8 e)
# Min-Max normalization: use Length attribute, this is the 11th column - V11
L<- c(AUTO[, 11])
LMinMax <- (L - min(L))/(max(L) - min(L))
LMinMax

# z-score normalization: use height attribute, this is the 13th column - V13
H <- c(AUTO[, 13])
HZScore <- (H - mean(H))/sd(H)
HZScore


# DataPrep Item 8 f)
# Relabel: use drive-wheels attribute, this is the 8th column - V8
R <- c(AUTO[, 8])
vRelabeled <- R

vRelabeled["4wd" == vRelabeled] <- "4 Wheel Drive"
vRelabeled["fwd" == vRelabeled] <- "Forward Wheel Drive"
vRelabeled["rwd" == vRelabeled] <- "Rear Wheel Drive"
vRelabeled

# DataPrep Item 8 g) h)
# Decode numeric categories: use body-style attribute, this is the 7th column - V7
v <- c(AUTO[, 7])
v
#As numeric attribute is not available, first convert body style category 
# (hardtop, wagon, sedan, hatchback, convertible) to numeric and then decode 
# numeric categories
v["hardtop" == v] <- 1
v["wagon" == v] <- 2
v["sedan" == v] <- 3
v["hatchback" == v] <- 4
v["convertible" == v] <- 5
#CAST non-numeric to numeric
v <- as.numeric(v)
v
# 1 - hardtop, 2 - wagon, 3 - sedan 4 - hatchback 5 - convertible
v[v==1] <- "hardtop"
v[v==2] <- "wagon"
v[v==3] <- "sedan"
v[v==4] <- "hatchback"
v[v==5] <- "convertible"
v

# DataPrep Item 8 i)
# Binarize: use drive-wheels attribute, this is the 8th column - V8
R <- c(AUTO[, 8])
R
#three different wheels drive: 4wd, fwd and rwd
fourwd <- R == "4wd"
fwd <- R == "fwd"
rwd <- R == "rwd"
fourwd; fwd; rwd

# better presentation
fourwd <- as.numeric(fourwd)
fwd <- as.numeric(fwd)
rwd <- as.numeric(rwd)
fourwd; fwd; rwd

# DataPrep Item 8 j)
# Discretization: use curb-weight attribute, it is the 14th column - v14
v <- c(AUTO[, 14])
v
numberOfBins <- 3
vMax <- max(v)
vMin <- min(v)
vRange <- vMax - vMin
binRange <- vRange / numberOfBins
bin1Min <- -Inf
bin1Max <- vMin + binRange
bin2Max <- bin1Max + binRange
bin3Max <- +Inf
bin1Min
bin1Max
bin2Max
bin3Max
discretizedV <- v
discretizedV[bin1Min < v & v <= bin1Max] <- "L" # Low
discretizedV[bin1Max < v & v <= bin2Max] <- "M" # Med
discretizedV[bin2Max < v & v  < bin3Max] <- "H" # High
discretizedV

# One way to do equal area dicretization
v <- c(AUTO[, 14])
length(v) # 205 / 3 is approx 68; Therefore aim for approx 68 items per bucket
sort(v)

#   3  3  4  4  5  5  5  5  5  5  5  6  6  6  6  6  7  7  7  7  8  8  9 12 23 24 25 81
# |--------------------------------|--------------------------|------------------------|
# bin1Max is 2275, bin2Max is 2756
numberOfBins <- 3
vSorted <- sort(v)
binRange <- length(vSorted) / numberOfBins
bin1Min <- -Inf
bin1Max <- vSorted[round(binRange)]
bin2Max <- vSorted[round(2*binRange)]
bin3Max <- +Inf
discretizedV <- v
discretizedV[bin1Min < v & v <= bin1Max] <- "L"
discretizedV[bin1Max < v & v <= bin2Max] <- "M"
discretizedV[bin2Max < v & v <  bin3Max] <- "H"
discretizedV
